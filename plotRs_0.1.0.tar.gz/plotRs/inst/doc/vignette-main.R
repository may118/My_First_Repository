## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup---------------------------------------------------------------
library(plotRs)
library(R.matlab)

## ------------------------------------------------------------------------
#we use two .. to go up a directory then find the folder 
#within windows there is two hidden directories . and .. 
#the . denotes the current directory and .. is used to go up a directory
source("..//R//findAvg.R")
source("../R//readData.R")

## ------------------------------------------------------------------------
#import data from chamber matlab file
rsIn = readData('..//inst//extdata//chamData.mat')

## ------------------------------------------------------------------------
master = list()
i = 1

while(i<6)
{
  master[[i]] = findAvg(rsIn,i)
  i = i+1
}

## ------------------------------------------------------------------------
#changing the margins of the data
par(mar = c(1,1,1,1))
par(mfrow=c(5,1))

## ------------------------------------------------------------------------
#number for starting year
year = 2014

#plot the 5 years
for (i in 1:5)
{
  plot(master[[i]], pch = 16, main = year, xlab = "Day of Year", ylab = "Rs (µmol CO2/m2/s)")
  
  #set custom x axis
  axis(1, seq(0,365,25))
  
  #set custom y axis
  axis(2, seq(0,12,2))
  
  year = year+1
}

